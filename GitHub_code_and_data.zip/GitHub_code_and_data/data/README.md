# Development-duration inputs

`supplied_summary_values.csv` contains 40 digitized duration summaries. All numerical values are retained from the analysis input. The release changes the descriptive `provenance` field to state the acquisition method; it does not certify extraction accuracy.

| Column | Meaning |
| --- | --- |
| Stage | `Pupal`: egg to pupariation; `Adult`: egg to adult emergence. These are endpoints, not pupal-stage duration or adult longevity. |
| Diet | Nutrient treatment label: 100%, 50%, 25% or 12%. The source's 12.5% treatment is abbreviated to 12%. |
| Temp | Constant experimental temperature in degrees Celsius: 15, 20, 25, 30 or 35. |
| Days | Digitized duration in days. |
| rate | Reciprocal duration, in day⁻¹. |
| source_sheet | Worksheet A for egg-to-pupariation values; C for egg-to-adult-emergence values. |
| provenance | Description of acquisition from published figures with WebPlotDigitizer. |

`supplied_original_workbook.ods` retains the source workbook. Worksheets B and D contain degree-day quantities; they are not extra observations. `Equations_used_symbolic.csv` contains the eight reference expressions used for numerical-domain diagnostics, distinct from the expressions refitted inside held-temperature folds.

Source: Florez-Cuadros M, Berkebile D, Brewer G, Taylor DB. Effects of Diet Quality and Temperature on Stable Fly (Diptera: Muscidae) Development. Insects. 2019;10:207. https://doi.org/10.3390/insects10070207

The extractor reported approximately 1% error from WebPlotDigitizer. The original extraction project is unavailable. The summaries lack replicate identifiers, variance estimates and sample-size weights. They are not 40 independent replicate observations.

The source study reports no adult emergence at the lowest diet at 15, 20 and 35 °C, while the digitized dataset includes durations at those temperatures. The corresponding adult curves are retained for numerical illustration and cannot establish successful-emergence durations for those treatments. The approximately 1% extraction estimate does not resolve this outcome-assignment limitation. Do not reinterpret missing emergence as zero days or impute durations to maintain five-temperature coverage.

`file_manifest.json` records release-file hashes. The pre-release numerical input hash is documented in `docs/release_changes.md`; its difference reflects the descriptive provenance-field update and newline normalization.
