# Spatial climate scenarios and model agreement

The study-context area is Lancaster County, Nebraska (FIPS 31109), which contains Firth. The source stable-fly colony originated from flies collected near Firth; the development experiments used laboratory chambers. These maps provide geographic climate scenarios.

Climate source: PRISM Group, Oregon State University, https://prism.oregonstate.edu/normals/, accessed 25 October 2026. The retained data are monthly mean-air-temperature normals for 1991–2020, version M5, at native 2.5-arc-minute resolution (approximately 4 km), in degrees Celsius. Boundaries are from U.S. Census Bureau TIGERweb. Source metadata, URLs and hashes are retained in this directory.

The Nebraska and Lancaster County GeoTIFFs each contain twelve bands, January through December. Cropping retains native cells without resampling. CSV files ending in `temperature_grid_cell_centres.csv` give WGS84 cell-centre coordinates and monthly values; these are modeled raster cells, not weather-station records. The county contains 130 cells.

All six canonical full-data fits and the nominal symbolic fit (λ=0.01, seed 20261023) are evaluated on the same climate cells. Cells outside 15–35 °C are masked, not clamped. All county cells are in range for May–September; none is in range in the other seven monthly normals. Out-of-domain months have explicit statuses rather than zero development rates.

`spatial_model_agreement_by_month.csv` contains 576 month–group–family records, including 240 in-domain comparisons. Signed differences use symbolic minus canonical rates. RMSE and MAE are in day⁻¹. Pearson correlation is descriptive; no independent-cell significance test is performed.

SSIM is computed from numerical rate arrays. Only centres with entirely valid paired windows contribute. The primary setting is a 7×7-cell window with population covariance and fixed data range 0.2 day⁻¹. All combinations of window sizes 3, 5 and 7 and data ranges 0.1, 0.2 and 0.4 are retained. July has 28 valid centres for the primary setting. High correlation or SSIM does not establish agreement with observed biological outcomes.

The included climate crops allow projection without downloading national grids:

```sh
python code/project_spatial_models.py
```

To repeat the cropping, obtain the source grids listed in `prism_download_manifest.json`, extract each month into a directory named `01` through `12`, and run:

```sh
python code/prepare_spatial_climate.py --source-dir /path/to/month/folders
python code/project_spatial_models.py
```

Both model families share climate forcing. A nonlinear rate evaluated at monthly mean air temperature differs from a mean rate under fluctuating substrate temperatures. Spatial and temporal biological accuracy require independent development observations.

Data attribution: PRISM Group, Oregon State University, https://prism.oregonstate.edu; data terms https://prism.oregonstate.edu/terms/. Boundaries: U.S. Census Bureau TIGERweb.
