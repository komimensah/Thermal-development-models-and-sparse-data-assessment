"""Calculate conditional duration-error bounds for quadratic held-temperature fits.

Held-temperature predictions are linear in the input rates. Prediction bounds
are exact over the declared rate box. Maximum pooled RMSE is checked at every
vertex; minimum RMSE is obtained by bounded convex least squares. These are
deterministic sensitivity bounds, not confidence intervals or PySR robustness.
"""
from pathlib import Path
from itertools import product
import json
import numpy as np
import pandas as pd
from scipy.optimize import lsq_linear
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]

def rate_bounds(days,kind):
    """Invert positive duration bounds exactly to obtain rate bounds."""
    days=np.asarray(days,dtype=float)
    delta=.01*days if kind=='relative_one_percent' else np.ones_like(days)
    if np.any(days-delta<=0):raise ValueError('Duration uncertainty includes zero')
    return 1/(days+delta),1/(days-delta),delta

def quadratic_cv_matrix(temp):
    """Construct the linear map from input rates to held-temperature predictions."""
    t=np.asarray(temp,dtype=float);x=(t-25)/10
    design=np.column_stack([np.ones(len(t)),x,x*x])
    if len(np.unique(t))<4:raise ValueError('Need at least four temperatures for these quadratic CV bounds')
    weights=np.zeros((len(t),len(t)))
    for i in range(len(t)):
        keep=np.arange(len(t))!=i
        if np.linalg.matrix_rank(design[keep])<3:raise ValueError('Rank-deficient quadratic training design')
        weights[i,keep]=design[i]@np.linalg.pinv(design[keep])
    return weights

def interval_linear(weights,low,high):
    """Find exact extrema of a linear map over a rectangular input interval."""
    pos=np.maximum(weights,0);neg=np.minimum(weights,0)
    return pos@low+neg@high,pos@high+neg@low

def rmse_bounds(matrix,low,high):
    """Calculate the convex minimum and vertex maximum of pooled prediction RMSE."""
    corners=np.array([np.where(bits,high,low) for bits in product([False,True],repeat=len(low))])
    rmse=np.sqrt(np.mean((corners@matrix.T)**2,axis=1))
    scale=.05
    best=lsq_linear(matrix,np.zeros(len(low)),bounds=(low/scale,high/scale),tol=1e-14,max_iter=1000)
    if not best.success:raise RuntimeError('Minimum bound optimization failed')
    minimum=float(np.linalg.norm(matrix@(best.x*scale))/np.sqrt(len(low)))
    return minimum,float(rmse.max()),len(corners),float(best.optimality)

def run():
    """Evaluate the two declared duration-error scenarios for every stage–diet group."""
    data=pd.read_csv(ROOT/'data/supplied_summary_values.csv');bounds=[];folds=[];intervals=[]
    baseline=pd.read_csv(ROOT/'results/baseline_cv_summary.csv')
    for (stage,diet),g in data.groupby(['Stage','Diet']):
        g=g.sort_values('Temp');t=g.Temp.to_numpy();days=g.Days.to_numpy();y=1/days
        w=quadratic_cv_matrix(t);a=w-np.eye(len(t));nominal=float(np.sqrt(np.mean((a@y)**2)))
        original=baseline[(baseline.Stage==stage)&(baseline.Diet==diet)&(baseline.Model=='Quadratic')&(baseline.split_type=='all')].iloc[0]
        assert np.isclose(nominal,original.RMSE,rtol=1e-10,atol=1e-12)
        for scenario in ['relative_one_percent','absolute_one_day']:
            low,high,delta=rate_bounds(days,scenario)
            predlow,predhigh=interval_linear(w,low,high);pred=w@y
            minimum,maximum,vertices,optimality=rmse_bounds(a,low,high)
            assert minimum<=nominal+1e-10 and nominal<=maximum+1e-10
            bounds.append(dict(Stage=stage,Diet=diet,Model='Quadratic',scenario=scenario,
               nominal_cv_RMSE=nominal,min_cv_RMSE=minimum,max_cv_RMSE=maximum,
               relative_min_change_percent=100*(minimum/nominal-1),
               relative_max_change_percent=100*(maximum/nominal-1),
               vertices_checked=vertices,min_solver_optimality=optimality,
               interpretation='Conditional deterministic bounds on digitized durations; not confidence intervals'))
            for i in range(len(t)):
                intervals.append(dict(Stage=stage,Diet=diet,Temp=t[i],scenario=scenario,
                    nominal_days=days[i],duration_half_width_days=delta[i],
                    duration_low=days[i]-delta[i],duration_high=days[i]+delta[i],
                    nominal_rate=y[i],rate_low=low[i],rate_high=high[i]))
                folds.append(dict(Stage=stage,Diet=diet,held_Temp=t[i],scenario=scenario,
                    nominal_prediction=pred[i],prediction_low=predlow[i],prediction_high=predhigh[i],
                    nominal_observed_rate=y[i],observed_rate_low=low[i],observed_rate_high=high[i],
                    error_low=predlow[i]-high[i],error_high=predhigh[i]-low[i],
                    type='endpoint_extrapolation' if i in [0,len(t)-1] else 'interior_interpolation'))
    summary=pd.DataFrame(bounds)
    summary.to_csv(ROOT/'results/digitization_quadratic_cv_bounds.csv',index=False)
    pd.DataFrame(folds).to_csv(ROOT/'results/digitization_quadratic_fold_bounds.csv',index=False)
    pd.DataFrame(intervals).to_csv(ROOT/'results/digitization_input_intervals.csv',index=False)
    config=dict(source='WebPlotDigitizer extraction; approximately 1% extraction error reported by the extractor',
      scenarios={'relative_one_percent':'Each supplied duration independently allowed within +/-1% of itself; a sensitivity assumption',
                 'absolute_one_day':'Each digitized duration allowed within +/-1 day as a separate sensitivity scenario'},
      method='Quadratic least-squares CV only; all 32 vertices per group for maximum RMSE; convex bounded least squares for minimum; exact linear prediction bounds',
      limitations=['Not sampling uncertainty','Not a confidence interval','Does not establish PySR robustness','Does not correct series assignment, curve-vs-marker errors, missing outcomes or wrong calibration','Temperature is kept fixed at the stated experimental setpoints'],
      data_status='Forty digitized summary values retained without numerical modification')
    (ROOT/'results/digitization_sensitivity_configuration.json').write_text(json.dumps(config,indent=2))
    fig,axs=plt.subplots(1,2,figsize=(11,4.5),sharey=True)
    for ax,scenario,title in zip(axs,['relative_one_percent','absolute_one_day'],['Hypothetical ±1% of each duration','Hypothetical ±1 day per duration']):
        h=summary[summary.scenario==scenario].reset_index(drop=True);yy=np.arange(len(h))
        ax.hlines(yy,h.min_cv_RMSE,h.max_cv_RMSE,color='#244c68',lw=3)
        ax.scatter(h.nominal_cv_RMSE,yy,color='black',s=22,zorder=3)
        ax.set_yticks(yy,h.Stage+' '+h.Diet);ax.invert_yaxis();ax.set_title(title,fontsize=11)
        ax.set_xlabel('Quadratic held-temperature RMSE (day⁻¹)');ax.grid(axis='x',alpha=.2)
    fig.suptitle('Conditional digitization sensitivity on supplied values',fontsize=13)
    fig.text(.5,.015,'Bars show deterministic bounds, not confidence intervals. Black dots show nominal RMSE. Other model families are not assessed here.',ha='center',fontsize=8)
    fig.tight_layout(rect=[0,.06,1,.94]);fig.savefig(ROOT/'figures/digitization_sensitivity.png',dpi=220);plt.close(fig)
    print(summary[['Stage','Diet','scenario','nominal_cv_RMSE','min_cv_RMSE','max_cv_RMSE']].to_string(index=False))

if __name__=='__main__':run()
