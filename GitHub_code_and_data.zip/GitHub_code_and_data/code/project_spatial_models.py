"""Spatial model agreement on retained PRISM normals; no biological validation.
Uses existing full-data model fits; does not choose a winning model by map agreement.
"""
from pathlib import Path
import json,calendar
import numpy as np
import pandas as pd
import rasterio
from scipy.ndimage import minimum_filter
from skimage.metrics import structural_similarity
from reanalyse import fn,MODELS
from summarize_pysr import evaluate_equation
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from shapely.geometry import shape
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'spatial';PRED=OUT/'predicted_rates';PRED.mkdir(exist_ok=True)

def score(a,b,domain):
    """Compare finite paired rate arrays with equal weighting per native climate cell."""
    valid=domain&np.isfinite(a)&np.isfinite(b);x=a[valid];y=b[valid]
    rec={'n_domain_cells':int(domain.sum()),'n_paired_finite':int(valid.sum()),'nonfinite_symbolic_cells':int((domain&~np.isfinite(a)).sum()),'nonfinite_canonical_cells':int((domain&~np.isfinite(b)).sum()),'negative_canonical_cells':int((domain&np.isfinite(b)&(b<0)).sum())}
    if not len(x):return rec|dict(status='No valid in-domain cells')
    d=x-y
    r=float(np.corrcoef(x,y)[0,1]) if np.std(x)>1e-12 and np.std(y)>1e-12 else np.nan
    return rec|dict(status='complete',Pearson_r=r,mean_signed_difference=float(d.mean()),MAE=float(abs(d).mean()),RMSE=float(np.sqrt(np.mean(d*d))),max_absolute_difference=float(abs(d).max()),symbolic_mean_rate=float(x.mean()),canonical_mean_rate=float(y.mean()))

def ssim_scores(a,b,domain):
    """Compute SSIM only at centres with a fully valid paired neighborhood.
    
    Mask fill values never enter an accepted window. All declared window sizes and
    reference data ranges are retained as sensitivity settings."""
    valid=domain&np.isfinite(a)&np.isfinite(b);a=np.where(valid,a,0.);b=np.where(valid,b,0.)
    out={}
    for win in [3,5,7]:
      good=minimum_filter(valid.astype('uint8'),size=win,mode='constant',cval=0).astype(bool)
      n=int(good.sum());out[f'SSIM_w{win}_valid_window_centres']=n
      for dr in [.1,.2,.4]:
       val=np.nan
       if n:
        _,sim=structural_similarity(a,b,data_range=dr,win_size=win,full=True,use_sample_covariance=False)
        val=float(sim[good].mean())
       out[f'SSIM_w{win}_range_{dr:g}']=val
    return out

def main():
    """Project saved full-data fits onto in-domain monthly climate cells."""
    with rasterio.open(OUT/'Lancaster_County_Nebraska_PRISM_tmean_1991_2020_monthly_4km.tif') as src:
      temp=src.read().astype(float);profile=src.profile.copy();bounds=src.bounds
    domain=np.isfinite(temp)&(temp>=15)&(temp<=35)
    fits=pd.read_csv(ROOT/'results/baseline_full_fits.csv')
    sr=pd.read_csv(ROOT/'results/pysr_runs.csv');sr=sr[(sr.fold=='full')&np.isclose(sr.search_lambda,.01)]
    assert len(sr)==8 and sr.status.eq('complete').all()
    records=[];saved={};verification=[]
    for _,r in sr.iterrows():
      stage,diet=r.Stage,r.Diet;key=stage+'_'+diet.replace('%','')
      a=np.full(temp.shape,np.nan);a[domain]=evaluate_equation(r.equation,temp[domain])
      arrays={'Symbolic':a}
      for m in MODELS:
        fit=fits[(fits.Stage==stage)&(fits.Diet==diet)&(fits.Model==m)].iloc[0]
        b=np.full(temp.shape,np.nan)
        assert fit.success
        b[domain]=fn(m,temp[domain],json.loads(fit.parameters));arrays[m]=b
        for mon in range(12):
          rec={'Stage':stage,'Diet':diet,'canonical_model':m,'month':mon+1,'symbolic_lambda':.01,'symbolic_seed':20261023}
          rec.update(score(a[mon],b[mon],domain[mon]));rec.update(ssim_scores(a[mon],b[mon],domain[mon]))
          records.append(rec)
      saved[(stage,diet)]=arrays
      for m,v in arrays.items():
        out=PRED/f'{key}_{m}_rate_day_inverse.tif'
        with rasterio.open(out,'w',**profile) as dst:
          dst.write(v.astype('float32'))
          for mon in range(1,13):dst.set_band_description(mon,calendar.month_name[mon]);dst.set_band_unit(mon,'day-1')
          dst.update_tags(temperature_domain_C='15 to 35; outside domain masked, not clamped',interpretation='Model projection scenario; no independent biological accuracy validation',model=m)
        with rasterio.open(out) as rd:
          assert rd.transform==profile['transform'] and rd.crs==profile['crs']
          assert np.allclose(rd.read(),v,rtol=1e-6,atol=1e-9,equal_nan=True)
        verification.append(dict(file=out.name,roundtrip_pass=True))
    metrics=pd.DataFrame(records);metrics.to_csv(OUT/'spatial_model_agreement_by_month.csv',index=False)
    assert len(metrics)==576
    # Independently recompute July Schoolfield deltas by exported GeoTIFF values.
    for _,r in metrics[(metrics.month==7)&(metrics.canonical_model=='Schoolfield_high')].iterrows():
      k=r.Stage+'_'+r.Diet.replace('%','')
      with rasterio.open(PRED/f'{k}_Symbolic_rate_day_inverse.tif') as s,rasterio.open(PRED/f'{k}_Schoolfield_high_rate_day_inverse.tif') as c:
        d=s.read(7).astype(float)-c.read(7).astype(float);d=d[np.isfinite(d)]
        assert np.isclose(np.sqrt(np.mean(d*d)),r.RMSE,rtol=1e-5,atol=1e-8)
    # SSIM identity and offset tests check implementation, not empirical claims.
    a=np.arange(144,dtype=float).reshape(12,12)/2000;valid=np.ones_like(a,dtype=bool)
    assert np.isclose(ssim_scores(a,a,valid)['SSIM_w7_range_0.2'],1)
    offset=score(a,a+.01,valid);assert np.isclose(offset['RMSE'],.01) and np.isclose(offset['Pearson_r'],1)
    july=metrics[(metrics.month==7)&(metrics.canonical_model=='Schoolfield_high')]
    diffs=[saved[(r.Stage,r.Diet)]['Symbolic'][6]-saved[(r.Stage,r.Diet)]['Schoolfield_high'][6] for _,r in sr.sort_values(['Stage','Diet']).iterrows()]
    lim=max(float(np.nanmax(abs(d))) for d in diffs)
    fig,axs=plt.subplots(2,4,figsize=(10,8),sharex=True,sharey=True)
    g=shape(json.loads((OUT/'Lancaster_County_Nebraska.geojson').read_text())['features'][0]['geometry'])
    for ax,d,(_,r) in zip(axs.flat,diffs,sr.sort_values(['Stage','Diet']).iterrows()):
      im=ax.imshow(d,extent=[bounds.left,bounds.right,bounds.bottom,bounds.top],origin='upper',interpolation='nearest',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim))
      for poly in ([g] if g.geom_type=='Polygon' else g.geoms):
       x,y=poly.exterior.xy;ax.plot(x,y,'k-',lw=.6)
      ax.set_title(f'{r.Stage} {r.Diet}',fontsize=10);ax.set_xticks([]);ax.set_yticks([])
    cax=fig.add_axes([.88,.24,.022,.48]);fig.colorbar(im,cax=cax,label='Symbolic − Schoolfield high rate (day⁻¹)')
    fig.suptitle('Lancaster County, Nebraska • July 1991–2020 climate scenario\nFull-data symbolic fit (λ=0.01) versus high-temperature Sharpe–Schoolfield',fontsize=11)
    fig.text(.06,.03,'PRISM Group, Oregon State University • https://prism.oregonstate.edu • accessed 25 October 2026\nNative ~4 km grid; 130 cells per panel. Model differences, not observed biological accuracy.',fontsize=8)
    fig.subplots_adjust(top=.87,bottom=.1,right=.84,hspace=.1,wspace=.12)
    fig.savefig(ROOT/'figures/Lancaster_July_spatial_difference.png',dpi=220);plt.close(fig)
    conf={'scope':'Agreement of model projections, not accuracy against independent observations','climate':'PRISM 1991–2020 monthly normals at native ~4 km grid','county':'Lancaster, NE, FIPS 31109','domain_C':[15,35],'outside_domain':'masked; never clamped','model_comparisons':'All six canonical full-data fits vs nominal symbolic full-data fit; no family selected using spatial metrics','equal_cell_weighting':True,'correlation':'Pearson r; no p-value or independence claim','SSIM':'Local uniform windows, population covariance; only centres whose entire window has valid paired cells; outside-mask fill never enters accepted windows','ssim_window_sizes_cells':[3,5,7],'ssim_reference_data_ranges_day_inverse':[.1,.2,.4],'primary_ssim':'7-cell window and fixed 0.2 day^-1 range; sensitivity settings all retained','main_map':'July chosen as midsummer illustration, not selected for favorable agreement; all twelve monthly statuses reported','interpretation_limit':'r evaluated at a monthly normal temperature is not the time average of nonlinear r(T); air temperature is not larval substrate temperature; common forcing and narrow local climate gradients can yield high correlation'}
    (OUT/'spatial_configuration.json').write_text(json.dumps(conf,indent=2))
    (OUT/'spatial_verification.json').write_text(json.dumps({'exported_prediction_files':len(verification),'all_roundtrip_checks_passed':True,'july_rmse_independently_recomputed_from_exports':8,'ssim_identity_and_offset_checks':'PASS','planned_month_group_family_records':576,'completed_in_domain_comparisons':int(metrics.status.eq('complete').sum()),'source_temperature_values_modified':False},indent=2))
    print(july[['Stage','Diet','n_paired_finite','Pearson_r','MAE','RMSE','SSIM_w7_range_0.2','SSIM_w7_valid_window_centres']].to_string(index=False))
if __name__=='__main__':main()
