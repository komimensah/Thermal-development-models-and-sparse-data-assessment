"""Extract day-valued development summaries from workbook sheets A and C.

Degree-day sheets B and D provide cross-sheet checks and are not fitted.
Usage: python code/prepare_inputs.py --source /path/to/source_package
"""
from pathlib import Path
from zipfile import ZipFile
import argparse,csv,json,hashlib
from lxml import etree
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);args=p.parse_args()
source=args.source
ns={'t':'urn:oasis:names:tc:opendocument:xmlns:table:1.0','x':'urn:oasis:names:tc:opendocument:xmlns:text:1.0'}
books=list((source/'Data').glob('*.ods'))
if len(books)!=1:raise ValueError('Expected exactly one supplied ODS workbook; choose a source directory explicitly')
values={}
with ZipFile(books[0]) as z:
 for tab in etree.fromstring(z.read('content.xml')).xpath('//t:table',namespaces=ns):
  sheet=tab.get('{'+ns['t']+'}name');values[sheet]={}
  for row in tab.xpath('./t:table-row',namespaces=ns):
   v=[' '.join(c.xpath('.//x:p//text()',namespaces=ns)) for c in row.xpath('./t:table-cell',namespaces=ns)]
   if len(v)>2 and v[0] in ['100%','50%','25%','12%']:values[sheet][(v[0],float(v[1]))]=float(v[2])
rows=[];check=[]
for a,b,stage in [('A','B','Pupal'),('C','D','Adult')]:
 for (diet,temp),days in values[a].items():
  if days<=0:raise ValueError('Duration must be positive; emergence failures require a separate status')
  rows.append(dict(Stage=stage,Diet=diet,Temp=temp,Days=days,rate=1/days,source_sheet=a,provenance='Published-figure summaries digitized with WebPlotDigitizer'))
  given=values[b].get((diet,temp));expected=days*(temp-10)
  check.append(dict(Stage=stage,Diet=diet,Temp=temp,Days=days,DD10_in_workbook=given,
    DD10_from_days=expected,difference=given-expected if given is not None else None,
    agrees=given is not None and abs(given-expected)<1e-8,
    interpretation='Cross-sheet consistency only if sheets refer to the same observations'))
for path,rs in [(ROOT/'data/supplied_summary_values.csv',rows),(ROOT/'results/workbook_DD10_consistency.csv',check)]:
 with path.open('w') as f:w=csv.DictWriter(f,fieldnames=rs[0]);w.writeheader();w.writerows(rs)
manifest={str(f.relative_to(source)):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in source.rglob('*') if f.is_file() and not f.name.startswith('~$')}
(ROOT/'data/source_manifest.json').write_text(json.dumps(manifest,indent=2))
print('Extracted',len(rows),'digitized duration summaries from sheets A and C.')
