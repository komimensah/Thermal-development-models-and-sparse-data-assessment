# Optional R launcher for projection of saved models onto monthly climate grids.
# Usage: Rscript code/Spatial_analysis.R /absolute/path/to/python
# The calculations are implemented in Python; R does not fit a separate model.
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Supply the Python executable as the only argument")
script_arg <- grep("^--file=", commandArgs(), value = TRUE)
script_dir <- dirname(normalizePath(sub("^--file=", "", script_arg)))
status <- system2(args[1], shQuote(file.path(script_dir, "project_spatial_models.py")))
if (status != 0L) stop("Spatial comparison failed; inspect the Python error output")
message("Spatial model-agreement calculations completed. Results are in spatial/.")
