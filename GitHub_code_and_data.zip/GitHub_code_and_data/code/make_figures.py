"""Plot the model-assessment workflow and reference-expression domain diagnostics.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
ROOT=Path(__file__).resolve().parents[1]

fig,ax=plt.subplots(figsize=(10,4.5));ax.axis('off');ax.set(xlim=(0,10),ylim=(0,5))
boxes=[(3.1,3.75,3.8,.65,'Digitized durations and developmental endpoints'),
       (.3,2.3,4.2,.85,'Canonical thermal models\nSix explicitly labelled families'),
       (5.5,2.3,4.2,.85,'Symbolic expression search\nExplicit settings and complexity'),
       (2.1,.95,5.8,.85,'Refit within each held-temperature fold\nSeparate interpolation and extrapolation'),
       (2.1,.10,5.8,.65,'Check uncertainty, curve shape and numerical domain')]
for x,y,w,h,txt in boxes:
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.05',facecolor='#edf1f5',edgecolor='#333333',lw=1))
 ax.text(x+w/2,y+h/2,txt,ha='center',va='center',fontsize=10)
for a,b in [((4,3.7),(2.4,3.2)),((6,3.7),(7.6,3.2)),((2.4,2.25),(4,1.85)),((7.6,2.25),(6,1.85)),((5,.9),(5,.8))]:
 ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='->',color='#333333',lw=1.2))
fig.text(.5,.015,'Projection maps show model disagreement; independent observations are needed for spatial validation.',ha='center',fontsize=9)
fig.tight_layout(rect=[0,.045,1,1]);fig.savefig(ROOT/'figures/revised_workflow.png',dpi=220);plt.close(fig)

data=pd.read_csv(ROOT/'data/supplied_summary_values.csv')
curves=pd.read_csv(ROOT/'results/original_equations_grid.csv')
fig,axs=plt.subplots(2,4,figsize=(12,6.5),sharex=True,sharey=True)
for ax,((stage,diet),d) in zip(axs.flat,data.groupby(['Stage','Diet'],sort=True)):
 c=curves[(curves.Stage==stage)&(curves.Diet==diet)&(curves.domain=='stress_test_only')]
 ax.axvspan(15,35,color='#dde9f2',label='Fitted interval')
 ax.plot(c.Temp,c.rate,color='#243f59',lw=1.3,label='Reference expression')
 ax.scatter(d.Temp,d.rate,s=15,c='black',label='Digitized values',zorder=5)
 invalid=c[~np.isfinite(c.rate)]
 if len(invalid):ax.scatter(invalid.Temp,np.full(len(invalid),.155),s=4,marker='|',c='#b32222',label='Nonfinite evaluation')
 ax.set_title(f'{stage} {diet}',fontsize=11);ax.set_ylim(0,.16);ax.set_xlim(0,50)
 ax.set_xlabel('Temperature (°C)')
axs[0,0].set_ylabel('Rate (day⁻¹)');axs[1,0].set_ylabel('Rate (day⁻¹)')
fig.suptitle('Reference expressions: numerical-domain diagnostics',fontsize=12)
fig.text(.5,.075,'Display limited to 0–0.16 day⁻¹. Adult 12% reaches 2.00 and Pupal 12% reaches 0.80 day⁻¹ in this stress domain.',ha='center',fontsize=9)
fig.legend(*axs[0,1].get_legend_handles_labels(),loc='lower center',ncol=4,fontsize=8)
fig.tight_layout(rect=[0,.11,1,.96]);fig.savefig(ROOT/'figures/original_equation_domain_checks.png',dpi=220);plt.close(fig)
