"""Verify saved symbolic expressions and summarize held-temperature predictions.

The script recalculates predictions without launching Julia or repeating search.
Complexity penalties are reported separately; none is selected by held-out error.
"""
from pathlib import Path
import ast,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]

def evaluate_equation(text,t):
    """Evaluate an archived latent expression and apply the fixed 0.05 exp(f) rate link."""
    tree=ast.parse(text,mode='eval')
    allowed=(ast.Expression,ast.BinOp,ast.UnaryOp,ast.Add,ast.Sub,ast.Mult,ast.USub,ast.UAdd,ast.Call,ast.Name,ast.Load,ast.Constant)
    for node in ast.walk(tree):
        if not isinstance(node,allowed):raise ValueError('Unexpected equation node '+str(type(node)))
        if isinstance(node,ast.Name) and node.id not in ['x0','sqrt','exp']:raise ValueError('Unexpected equation symbol')
        if isinstance(node,ast.Call) and (not isinstance(node.func,ast.Name) or node.func.id not in ['sqrt','exp']):raise ValueError('Unexpected function')
    with np.errstate(all='ignore'):
        latent=eval(compile(tree,'pysr_expression','eval'),{'__builtins__':{}},{'x0':np.asarray(t),'sqrt':np.sqrt,'exp':np.exp})
        return .05*np.exp(latent)

def tree_nodes(node):
    """Count nodes using the same structural convention as the search configuration."""
    if isinstance(node,ast.Expression):return tree_nodes(node.body)
    if isinstance(node,(ast.Name,ast.Constant)):return 1
    if isinstance(node,ast.UnaryOp) and isinstance(node.operand,ast.Constant):return 1
    if isinstance(node,ast.BinOp):return 1+tree_nodes(node.left)+tree_nodes(node.right)
    if isinstance(node,ast.Call):return 1+sum(tree_nodes(a) for a in node.args)
    raise ValueError('Unexpected tree node '+str(type(node)))

def main():
    """Check expression complexity, reproduce predictions and summarize each penalty."""
    data=pd.read_csv(ROOT/'data/supplied_summary_values.csv')
    runs=pd.read_csv(ROOT/'results/pysr_runs.csv')
    checks=[]
    for _,r in runs[runs.status.eq('complete')].iterrows():
        n=tree_nodes(ast.parse(r.equation,mode='eval'))
        checks.append(dict(Stage=r.Stage,Diet=r.Diet,fold=r.fold,search_lambda=r.search_lambda,
            complexity=r.complexity,serialized_tree_nodes=n,matches_backend_complexity=n==r.complexity))
    checks=pd.DataFrame(checks)
    assert checks.matches_backend_complexity.all()
    checks.to_csv(ROOT/'results/pysr_complexity_check.csv',index=False)
    cv=runs[runs.fold.str.startswith('hold_')].copy();summary=[];verified=0
    for _,r in cv[cv.status.eq('complete')].iterrows():
        computed=float(evaluate_equation(r.equation,[r.held_Temp])[0] if 'x0' in r.equation else evaluate_equation(r.equation,r.held_Temp))
        if not np.isclose(computed,r.predicted,rtol=1e-9,atol=1e-12):raise AssertionError('Stored prediction not reproduced from archived equation')
        assert np.isclose(r.predicted-r.observed,r.error)
        verified+=1
    for (stage,diet),g in data.groupby(['Stage','Diet']):
        expected=set(g.Temp)
        if len(expected)<5:continue
        for lam in [.001,.01,.1]:
            h=cv[(cv.Stage==stage)&(cv.Diet==diet)&np.isclose(cv.search_lambda,lam)]
            for kind in ['all','interior_interpolation','endpoint_extrapolation']:
                wanted=expected if kind=='all' else (set(sorted(expected)[1:-1]) if kind=='interior_interpolation' else {min(expected),max(expected)})
                f=h[h.held_Temp.isin(wanted)]
                complete=len(f)==len(wanted) and set(f.held_Temp)==wanted and f.status.eq('complete').all() and np.isfinite(f.predicted).all()
                summary.append(dict(Stage=stage,Diet=diet,Model='Symbolic new',search_lambda=lam,
                    split_type=kind,expected_folds=len(wanted),recorded_folds=len(f),
                    completed_folds=int(f.status.eq('complete').sum()),
                    RMSE=float(np.sqrt(np.mean(f.error**2))) if complete else np.nan,
                    MAE=float(abs(f.error).mean()) if complete else np.nan,
                    status='complete' if complete else 'INCOMPLETE do not rank'))
    summary=pd.DataFrame(summary);summary.to_csv(ROOT/'results/pysr_cv_summary.csv',index=False)
    bases=pd.read_csv(ROOT/'results/baseline_cv_summary.csv')
    comparison=bases[['Stage','Diet','Model','split_type','RMSE','MAE','status']].copy()
    comparison['search_lambda']=np.nan
    comparison=pd.concat([comparison,summary[['Stage','Diet','Model','split_type','RMSE','MAE','status','search_lambda']]],ignore_index=True)
    comparison.to_csv(ROOT/'results/all_models_cv_comparison.csv',index=False)
    overall=dict(recorded_runs=len(runs),planned_runs=160,
       complete_runs=int(runs.status.eq('complete').sum()),verified_fold_predictions_from_archived_equations=verified,
       planned_held_temperature_predictions=120,
       analysis_scope='Digitized summaries; complexity penalties reported separately without selection by held-out error',
       complete_plan=bool(len(runs)==160 and runs.status.eq('complete').all()))
    (ROOT/'results/pysr_run_verification.json').write_text(json.dumps(overall,indent=2))
    # Seed spread is prediction variability for full fits, not a biological CI.
    curves=pd.read_csv(ROOT/'results/pysr_full_curves.csv')
    seedcurves=curves[curves.fold.isin(['full','full_seed_2','full_seed_3'])]
    def finite_min(v):
        a=np.asarray(v);a=a[np.isfinite(a)];return float(a.min()) if len(a) else np.nan
    def finite_max(v):
        a=np.asarray(v);a=a[np.isfinite(a)];return float(a.max()) if len(a) else np.nan
    spread=seedcurves.groupby(['Stage','Diet','Temp']).agg(total_seed_runs=('rate','size'),
        finite_seed_runs=('rate',lambda v:int(np.isfinite(v).sum())),
        min_finite_rate=('rate',finite_min),max_finite_rate=('rate',finite_max)).reset_index()
    spread['finite_prediction_spread']=spread.max_finite_rate-spread.min_finite_rate
    spread.to_csv(ROOT/'results/pysr_seed_prediction_spread.csv',index=False)
    shape=[]
    for (stage,diet,fold),g in curves.groupby(['Stage','Diet','fold']):
        for label,low,high in [('training_range',15,35),('stress_test_only',0,50)]:
            h=g[g.Temp.between(low,high)].sort_values('Temp');v=h.rate.to_numpy();finite=np.isfinite(v)
            diff=np.diff(v);sign=np.sign(diff[np.isfinite(diff)&(abs(diff)>1e-10)])
            shape.append(dict(Stage=stage,Diet=diet,fold=fold,domain=label,n_grid_points=len(v),
                finite_fraction=float(finite.mean()),positive_fraction=float((finite&(v>0)).mean()),
                detected_peaks=int(np.sum((sign[:-1]>0)&(sign[1:]<0))),
                turning_points=int(np.sum(sign[1:]!=sign[:-1])),
                minimum_finite_rate=finite_min(v),maximum_finite_rate=finite_max(v),
                caveat='Finite-grid diagnostic, not a formal interval guarantee'))
    pd.DataFrame(shape).to_csv(ROOT/'results/pysr_shape_diagnostics.csv',index=False)
    fig,axs=plt.subplots(2,4,figsize=(13,6),sharex=True)
    for ax,((stage,diet),g) in zip(axs.flat,data.groupby(['Stage','Diet'])):
        ax.scatter(g.Temp,g.rate,color='black',s=18,label='Digitized values',zorder=4)
        for lam in [.001,.01,.1]:
            h=cv[(cv.Stage==stage)&(cv.Diet==diet)&np.isclose(cv.search_lambda,lam)].sort_values('held_Temp')
            ax.plot(h.held_Temp,h.predicted,marker='.',lw=1,label=f'λ={lam:g}')
        ax.set_title(f'{stage} {diet}');ax.set_xlabel('Held-out temperature (°C)');ax.grid(alpha=.15)
    axs[0,0].set_ylabel('Held-out rate prediction (day⁻¹)');axs[1,0].set_ylabel('Held-out rate prediction (day⁻¹)')
    fig.legend(*axs[0,0].get_legend_handles_labels(),loc='lower center',ncol=4,fontsize=9)
    fig.suptitle('Symbolic held-temperature predictions at three prespecified penalties')
    fig.tight_layout(rect=[0,.09,1,.95]);fig.savefig(ROOT/'figures/pysr_heldout_sensitivity.png',dpi=220);plt.close(fig)
    print(json.dumps(overall,indent=2))
    print(summary[summary.split_type=='all'].to_string(index=False))

if __name__=='__main__':main()
