"""Independent consistency checks on saved results without repeating optimization."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from reanalyse import fn
ROOT=Path(__file__).resolve().parents[1]
data=pd.read_csv(ROOT/'data/supplied_summary_values.csv')
folds=pd.read_csv(ROOT/'results/baseline_cv_folds.csv')
assert len(data)==40 and len(folds)==240
assert not data.duplicated(['Stage','Diet','Temp']).any()
assert set(data.Temp)=={15,20,25,30,35}
assert np.allclose(data.rate,1/data.Days)
assert not folds.duplicated(['Stage','Diet','Model','held_Temp']).any()
assert folds.n_train.eq(4).all()
checked=0
for _,r in folds.iterrows():
    if not r.success:continue
    p=json.loads(r.parameters)
    v=fn(r.Model,[r.held_Temp],p)[0]
    assert np.isclose(v,r.predicted,rtol=1e-10,atol=1e-12)
    assert np.isclose(v-r.observed,r.error,rtol=1e-10,atol=1e-12)
    checked+=1
    if r.Model=='Quadratic':
        g=data[(data.Stage==r.Stage)&(data.Diet==r.Diet)&(data.Temp!=r.held_Temp)]
        independent=np.polyfit(g.Temp,g.rate,2)
        assert np.isclose(np.polyval(independent,r.held_Temp),v,atol=1e-10)
summary=pd.read_csv(ROOT/'results/baseline_cv_summary.csv')
for _,r in summary.iterrows():
    g=folds[(folds.Stage==r.Stage)&(folds.Diet==r.Diet)&(folds.Model==r.Model)]
    if r.split_type!='all':g=g[g.split_type==r.split_type]
    if g.success.all():assert np.isclose(np.sqrt(np.mean(g.error**2)),r.RMSE)
    else:assert pd.isna(r.RMSE)
a=pd.read_csv(ROOT/'results/original_equations_audit.csv')
assert len(a)==8 and (a.RMSE_absolute_difference<1e-12).all()
report={'status':'PASS','verified_heldout_predictions':checked,'failed_heldout_fits':int((~folds.success).sum()),
  'expected_fold_rows':240,'independent_quadratic_check':'PASS',
  'original_symbolic_RMSE_reproduction':'PASS within 1e-12',
  'scope':'Computational consistency of saved predictions; independent biological validation is outside this check'}
if (ROOT/'results/pysr_runs.csv').exists():
    s=pd.read_csv(ROOT/'results/pysr_runs.csv')
    report['pysr_runs_recorded']=len(s);report['pysr_complete_runs']=int(s.status.eq('complete').sum())
    for _,r in s[s.fold.str.startswith('hold_')&s.status.eq('complete')].iterrows():
        assert np.isclose(r.predicted-r.observed,r.error)
    report['pysr_complete_outer_cv_folds']=int((s.fold.str.startswith('hold_')&s.status.eq('complete')).sum())
(ROOT/'results/verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
