"""Check exact linear bounds independently against enumerated vertices."""
from itertools import product
import numpy as np
from digitization_sensitivity import quadratic_cv_matrix,rate_bounds,interval_linear,rmse_bounds
t=np.array([15,20,25,30,35.]);d=np.array([60,25,12,8,10.]);y=1/d
w=quadratic_cv_matrix(t)
assert np.allclose(np.diag(w),0)
for i in range(5):
    keep=np.arange(5)!=i
    independently=np.polyval(np.polyfit(t[keep],y[keep],2),t[i])
    assert np.isclose(w[i]@y,independently,atol=1e-12)
for scenario in ['relative_one_percent','absolute_one_day']:
    lo,hi,delta=rate_bounds(d,scenario)
    vertices=np.array([np.where(bits,hi,lo) for bits in product([False,True],repeat=5)])
    predictions=vertices@w.T
    lower,upper=interval_linear(w,lo,hi)
    assert np.allclose(lower,predictions.min(axis=0))
    assert np.allclose(upper,predictions.max(axis=0))
    minimum,maximum,n,opt=rmse_bounds(w-np.eye(5),lo,hi)
    all_rmse=np.sqrt(np.mean((vertices@(w-np.eye(5)).T)**2,axis=1))
    assert np.isclose(maximum,all_rmse.max()) and minimum<=all_rmse.min()+1e-12 and n==32
    assert minimum<=np.sqrt(np.mean(((w-np.eye(5))@y)**2))<=maximum
lo,hi,_=rate_bounds(d,'relative_one_percent')
assert np.allclose(lo/y,1/1.01) and np.allclose(hi/y,1/.99)
print('PASS: train/test separation, independent polynomial fit, all-vertex prediction bounds, rate inversion and CV envelope')
