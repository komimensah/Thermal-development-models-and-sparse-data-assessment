"""Numerical intake checks for digitized development summaries.

This validates the analysis schema, not the accuracy of a graph extraction.
Run: python code/input_checks.py --data data/supplied_summary_values.csv
"""
from pathlib import Path
import json,argparse
import numpy as np
import pandas as pd

def read_summary_data(path):
    """Validate numeric fields, temperature design, duplicate keys and reciprocal rates."""
    d=pd.read_csv(path)
    required={'Stage','Diet','Temp','Days'}
    if not required.issubset(d):raise ValueError('Missing columns: '+str(sorted(required-set(d))))
    if d[list(required)].isna().any().any():raise ValueError('Missing input values; represent absent development as a separate outcome, not an imputed duration')
    for col in ['Temp','Days']:
        d[col]=pd.to_numeric(d[col],errors='raise')
        if not np.isfinite(d[col]).all():raise ValueError('Nonfinite '+col)
    if (d.Days<=0).any():raise ValueError('Development durations must be positive; no emergence is not zero days')
    if not set(d.Temp).issubset({15.,20.,25.,30.,35.}):raise ValueError('Temperature differs from the declared five-level experiment; review source labels or calibration without automatic rounding')
    if d.duplicated(['Stage','Diet','Temp']).any():raise ValueError('Duplicate group-temperature summary; reconcile duplicates or use a replicate-aware protocol')
    if 'point_type' in d:
        if d.point_type.eq('fitted_curve').any():raise ValueError('Fitted-curve values cannot be treated as observed summary points')
    computed=1/d.Days
    if 'rate' in d and not np.allclose(pd.to_numeric(d.rate),computed,rtol=1e-10,atol=1e-12):
        raise ValueError('Stored rate disagrees with 1/Days')
    d['rate']=computed
    return d

def intake_report(d):
    """Report numerical eligibility separately from biological interpretation."""
    groups=[]
    for (stage,diet),g in d.groupby(['Stage','Diet']):
        n=g.Temp.nunique()
        groups.append(dict(Stage=stage,Diet=diet,n_summary_values=len(g),n_temperature_levels=n,
            full_fit_residual_df={'two_mean_parameters':n-2,'three_mean_parameters':n-3,'four_mean_parameters':n-4},
            nominal_held_temperature_train_n=n-1,
            eligible_for_predeclared_five_temperature_comparison=n>=5,
            action='eligible for the five-temperature numerical comparison; biological interpretation is documented in data/README.md' if n>=5 else 'retain observations; skip the predeclared five-temperature comparison; do not impute missing outcomes'))
    return dict(groups=groups,rows=len(d),numerical_schema_pass=True,
        scientific_verification_pass=False,
        scientific_verification_reason='Numerical schema checks do not independently establish extraction accuracy or biological outcome validity; see data/README.md',
        used_units='Days; rate is reciprocal days. Degree-day sheets are not additional observations.')

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,default=root/'data/supplied_summary_values.csv');args=p.parse_args()
    report=intake_report(read_summary_data(args.data))
    (root/'results/input_intake_checks.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
