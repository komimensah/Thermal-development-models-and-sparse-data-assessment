"""Fit six canonical thermal-response families and assess held-temperature prediction.

Each fold uses four temperature summaries to predict the omitted fifth summary.
Nonlinear fits use fixed parameter bounds and deterministic multiple starts.
Failed fits, boundary solutions and conditioning diagnostics remain in the outputs.
Schoolfield_high is the four-parameter high-temperature model. Its stored Th
parameter is in degrees Celsius and is converted to kelvin during evaluation.
"""
from pathlib import Path
import json, sys, platform, warnings
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
DATA=pd.read_csv(ROOT/'data/supplied_summary_values.csv')
MODELS=['Quadratic','Briere','Logan','Lactin','Ratkowsky','Schoolfield_high']
SEED=20261023
NSTARTS=24
MAX_NFEV=2500

def fn(m,t,p):
    """Evaluate the named model in reciprocal days for temperatures in degrees Celsius."""
    t=np.asarray(t,dtype=float)
    with np.errstate(all='ignore'):
        if m=='Quadratic':
            x=(t-25)/10
            return p[0]+p[1]*x+p[2]*x*x
        if m=='Briere':
            a,tmin,tmax=p
            return np.where((t>tmin)&(t<tmax),a*t*(t-tmin)*np.sqrt(np.maximum(tmax-t,0)),0.)
        if m=='Logan':
            psi,rho,tmax,delta=p
            return psi*(np.exp(rho*t)-np.exp(rho*tmax-(tmax-t)/delta))
        if m=='Lactin':
            rho,tmax,delta,offset=p
            return np.exp(rho*t)-np.exp(rho*tmax-(tmax-t)/delta)+offset
        if m=='Ratkowsky':
            b,tmin=p
            return np.where(t>tmin,(b*(t-tmin))**2,0.)
        if m=='Schoolfield_high':
            # Standard high-temperature Schoolfield form, kB in eV/K, reference 25 C.
            # B0 is the non-deactivated reference normalization, not the realized rate at Tr.
            b0,e,eh,th=p; tk=t+273.15; tr=298.15; kb=8.617333262145e-5
            return b0*np.exp(-e/kb*(1/tk-1/tr))/(1+np.exp(eh/kb*(1/(th+273.15)-1/tk)))
    raise ValueError(m)

def bounds(m):
    # Fixed before validation, not estimated from held-out responses.
    """Return prespecified parameter bounds; held-out responses do not set these bounds."""
    return {
      'Briere':([1e-10,-10,35.01],[.01,14.99,60]),
      'Logan':([1e-7,.0001,35.01,.1],[10,.5,60,30]),
      'Lactin':([.0001,35.01,.1,-10],[.3,60,30,1]),
      'Ratkowsky':([1e-7,-10],[.1,14.99]),
      'Schoolfield_high':([1e-6,.01,.05,20],[2,2,10,60])
    }[m]

def fit(m,t,y):
    """Minimize rate-scale squared error and retain the best converged starting point."""
    if m=='Quadratic':
        x=(np.array(t)-25)/10
        xmat=np.array([np.ones(len(x)),x,x*x]).T
        p=np.linalg.lstsq(xmat,y,rcond=None)[0]
        return dict(p=p,success=True,boundary=False,jac=np.linalg.cond(xmat),nstarts=1,
                    train_rmse=float(np.sqrt(np.mean((fn(m,t,p)-y)**2))))
    lo,hi=map(np.array,bounds(m)); rng=np.random.default_rng(SEED)
    initial={'Briere':[.0001,10,40],'Logan':[.01,.05,40,5],
      'Lactin':[.01,40,3,-1],'Ratkowsky':[.01,10],
      'Schoolfield_high':[.1,.6,3,33]}[m]
    starts=[np.array(initial)]
    for _ in range(NSTARTS-1):
        p=lo+(hi-lo)*rng.uniform(.02,.98,len(lo))
        if m in ['Briere','Logan','Ratkowsky','Schoolfield_high']:
            p[0]=np.exp(rng.uniform(np.log(lo[0]*10),np.log(min(hi[0],.2))))
        starts.append(p)
    fits=[]
    def residual(p):
        r=(fn(m,t,p)-y)/.05
        return np.nan_to_num(r,nan=1e12,posinf=1e12,neginf=-1e12)
    for start in starts:
        try:
            z=least_squares(residual,start,bounds=(lo,hi),max_nfev=MAX_NFEV,
                ftol=1e-10,xtol=1e-10,gtol=1e-10,x_scale='jac')
            if z.success and np.all(np.isfinite(fn(m,t,z.x))):fits.append(z)
        except (ValueError,FloatingPointError): pass
    if not fits:return dict(p=None,success=False,boundary=None,jac=None,nstarts=0,train_rmse=np.nan)
    z=min(fits,key=lambda f:np.sum(f.fun**2))
    near=np.any(np.minimum((z.x-lo)/(hi-lo),(hi-z.x)/(hi-lo))<1e-4)
    return dict(p=z.x,success=True,boundary=bool(near),jac=float(np.linalg.cond(z.jac)),
                nstarts=len(fits),train_rmse=float(np.sqrt(np.mean((fn(m,t,z.x)-y)**2))))

def run():
    """Write full-data fits, held-temperature predictions, summaries and diagnostics."""
    records=[];full=[];residuals=[];curves=[]
    for (st,diet),group in DATA.groupby(['Stage','Diet'],sort=True):
        g=group.sort_values('Temp');t=g.Temp.to_numpy();y=g.rate.to_numpy()
        for m in MODELS:
            f=fit(m,t,y)
            row=dict(Stage=st,Diet=diet,Model=m,n=len(t),**{k:v for k,v in f.items() if k!='p'})
            if f['success']:
                p=f['p']; yh=fn(m,t,p); rss=np.sum((y-yh)**2); k=len(p)+1
                row.update(parameters=json.dumps(p.tolist()),K_including_variance=k,
                   train_R2=1-rss/np.sum((y-y.mean())**2),
                   AICc=(len(y)*np.log(rss/len(y))+2*k+2*k*(k+1)/(len(y)-k-1)) if len(y)>k+1 else np.nan,
                   AICc_reason='computed without common Gaussian constant' if len(y)>k+1 else 'n <= K + 1',residual_df=len(y)-len(p))
                for tt,yy,pp in zip(t,y,yh):residuals.append(dict(Stage=st,Diet=diet,Model=m,Temp=tt,observed=yy,predicted=pp,residual=yy-pp))
                for tt,pp in zip(np.linspace(15,35,401),fn(m,np.linspace(15,35,401),p)):
                    curves.append(dict(Stage=st,Diet=diet,Model=m,Temp=tt,rate=pp))
            full.append(row)
            for i in range(len(t)):
                keep=np.arange(len(t))!=i; f=fit(m,t[keep],y[keep]); pred=np.nan
                if f['success']:pred=float(fn(m,[t[i]],f['p'])[0])
                records.append(dict(Stage=st,Diet=diet,Model=m,held_Temp=t[i],n_train=int(sum(keep)),
                    split_type='endpoint_extrapolation' if i in [0,len(t)-1] else 'interior_interpolation',
                    observed=y[i],predicted=pred,error=pred-y[i],
                    success=f['success'] and np.isfinite(pred),boundary=f['boundary'],jac_condition=f['jac'],
                    parameters=json.dumps(f['p'].tolist()) if f['p'] is not None else '',
                    train_rmse=f['train_rmse'],converged_starts=f['nstarts']))
        print('Completed baseline fits and 5 held-temperature folds:',st,diet,flush=True)
        # Save incrementally, including all failures.
        pd.DataFrame(records).to_csv(ROOT/'results/baseline_cv_folds.csv',index=False)
        pd.DataFrame(full).to_csv(ROOT/'results/baseline_full_fits.csv',index=False)
    folds=pd.DataFrame(records)
    summaries=[]
    for keys,g in folds.groupby(['Stage','Diet','Model']):
        for kind in ['all','interior_interpolation','endpoint_extrapolation']:
            h=g if kind=='all' else g[g.split_type==kind]
            complete=h.success.all()
            summaries.append(dict(zip(['Stage','Diet','Model'],keys),split_type=kind,n_folds=len(h),
               successful_folds=int(h.success.sum()),RMSE=float(np.sqrt(np.mean(h.error**2))) if complete else np.nan,
               MAE=float(np.mean(abs(h.error))) if complete else np.nan,
               boundary_folds=int(h.boundary.fillna(False).sum()),
               status='complete' if complete else 'INCOMPLETE do not rank'))
    pd.DataFrame(summaries).to_csv(ROOT/'results/baseline_cv_summary.csv',index=False)
    pd.DataFrame(residuals).to_csv(ROOT/'results/baseline_residuals.csv',index=False)
    pd.DataFrame(curves).to_csv(ROOT/'results/baseline_curves.csv',index=False)
    config={'seed':SEED,'starts_per_nonlinear_fit':NSTARTS,'max_nfev':MAX_NFEV,
      'fit_loss':'unweighted squared error on rate scale','fixed_temperature_design_C':[15,20,25,30,35],
      'bounds':{m:bounds(m) for m in MODELS if m!='Quadratic'},
      'versions':{'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__},
      'status':'Canonical fits to digitized development summaries; parameter bounds and folds are recorded',
      'Schoolfield_high_definition':'B0*exp(-E/kB*(1/TK-1/298.15))/(1+exp(Eh/kB*(1/(Th+273.15)-1/TK)))'}
    (ROOT/'results/baseline_configuration.json').write_text(json.dumps(config,indent=2))
    fig,axs=plt.subplots(2,4,figsize=(13,6),sharex=True,sharey=True)
    curves=pd.DataFrame(curves)
    for ax,((st,diet),g) in zip(axs.flat,DATA.groupby(['Stage','Diet'],sort=True)):
        ax.scatter(g.Temp,g.rate,c='black',s=15,zorder=5,label='Digitized values')
        for m in MODELS:
            c=curves[(curves.Stage==st)&(curves.Diet==diet)&(curves.Model==m)]
            ax.plot(c.Temp,c.rate,label=m,alpha=.8,lw=1)
        ax.set_title(f'{st} {diet}');ax.set_ylim(-.01,.16);ax.set_xlabel('Temperature (°C)')
    axs[0,0].set_ylabel('Rate (day⁻¹)');axs[1,0].set_ylabel('Rate (day⁻¹)')
    handles,labels=axs[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=4,fontsize=8)
    fig.suptitle('Canonical fits to digitized development summaries',fontsize=12)
    fig.tight_layout(rect=[0,.10,1,.95]);fig.savefig(ROOT/'figures/baseline_fits.png',dpi=220);plt.close(fig)
    fig,axs=plt.subplots(2,4,figsize=(13,6),sharex=True,sharey=True)
    for ax,((st,diet),g) in zip(axs.flat,DATA.groupby(['Stage','Diet'],sort=True)):
        ax.scatter(g.Temp,g.rate,c='black',s=15,label='Digitized values')
        for m in MODELS:
            h=folds[(folds.Stage==st)&(folds.Diet==diet)&(folds.Model==m)].sort_values('held_Temp')
            ax.plot(h.held_Temp,h.predicted,marker='.',lw=.8,label=m)
        ax.set_title(f'{st} {diet}');ax.set_xlabel('Held-out temperature (°C)')
    axs[0,0].set_ylabel('Held-out prediction (day⁻¹)');axs[1,0].set_ylabel('Held-out prediction (day⁻¹)')
    fig.legend(*axs[0,0].get_legend_handles_labels(),loc='lower center',ncol=4,fontsize=8)
    fig.suptitle('Canonical held-temperature predictions — endpoint folds are extrapolation',fontsize=12)
    fig.tight_layout(rect=[0,.10,1,.95]);fig.savefig(ROOT/'figures/baseline_heldout.png',dpi=220);plt.close(fig)

if __name__=='__main__':run()
