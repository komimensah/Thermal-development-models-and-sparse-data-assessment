"""Evaluate the eight reference expressions and audit their training statistics.

Tree complexity counts each operator, variable occurrence and numerical literal.
Grid diagnostics describe finite values and shape; they are not interval proofs.
"""
from pathlib import Path
import ast, json, hashlib, platform
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
data = pd.read_csv(ROOT/'data/supplied_summary_values.csv')
eq = pd.read_csv(ROOT/'data/Equations_used_symbolic.csv')
out, gridrows, points = [], [], []

def expression_tree(text):
    text = text.split('=',1)[1].split(';')[0].strip()
    tree = ast.parse(text, mode='eval')
    allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Add, ast.Sub,
               ast.Mult, ast.USub, ast.UAdd, ast.Call, ast.Name, ast.Load, ast.Constant)
    for node in ast.walk(tree):
        if not isinstance(node,allowed): raise ValueError(type(node).__name__)
        if isinstance(node,ast.Name) and node.id not in ['x0','sqrt','exp']: raise ValueError(node.id)
        if isinstance(node,ast.Call) and (not isinstance(node.func,ast.Name) or node.func.id not in ['sqrt','exp']): raise ValueError('call')
    return tree

for _, r in eq.iterrows():
    tree = expression_tree(r.Equation)
    # Explicit AST convention: negated numeric literals count as one constant node.
    def counts(n):
        if isinstance(n,ast.Expression): return counts(n.body)
        if isinstance(n,ast.Constant): return (1,1)
        if isinstance(n,ast.Name): return (1,0)
        if isinstance(n,ast.UnaryOp) and isinstance(n.operand,ast.Constant): return (1,1)
        if isinstance(n,ast.UnaryOp):
            c,k=counts(n.operand); return c+1,k
        if isinstance(n,ast.Call):
            c,k=counts(n.args[0]); return c+1,k
        if isinstance(n,ast.BinOp):
            a,b=counts(n.left),counts(n.right); return a[0]+b[0]+1,a[1]+b[1]
        raise ValueError(type(n).__name__)
    complexity, constants = counts(tree)
    code = compile(tree,'supplied_equation','eval')
    def pred(x):
        with np.errstate(all='ignore'):
            return np.exp(eval(code,{'__builtins__':{}},{'x0':x,'sqrt':np.sqrt,'exp':np.exp}))
    d = data[(data.Stage==r.Stage)&(data.Diet==r.Diet)].sort_values('Temp')
    y = d.rate.to_numpy(); yhat=pred(d.Temp.to_numpy()); rss=np.sum((y-yhat)**2)
    rmse=np.sqrt(rss/len(y)); r2=1-rss/np.sum((y-y.mean())**2)
    result=dict(Stage=r.Stage,Diet=r.Diet,n=len(y),AST_nodes_log_expression=complexity,
        numeric_constant_occurrences=constants,reported_R2=r.R2,recomputed_R2=r2,
        reported_RMSE=r.RMSE,recomputed_RMSE=rmse,
        RMSE_absolute_difference=abs(rmse-r.RMSE),
        legacy_AIC_k3=5*np.log(rss/5)+6,
        conditional_AIC_constant_count=5*np.log(rss/5)+2*constants,
        AICc_status='Undefined using K=constants+residual variance since n<=K+1',
        warning='Constant occurrences are not effective search degrees of freedom; neither AIC is endorsed')
    for t,obs,phat in zip(d.Temp,y,yhat):points.append(dict(Stage=r.Stage,Diet=r.Diet,Temp=t,observed=obs,predicted=phat,residual=obs-phat))
    for lo,hi,label in [(15,35,'training_range'),(0,50,'stress_test_only')]:
        x=np.linspace(lo,hi,4001); p=pred(x); finite=np.isfinite(p)
        dif=np.diff(p); tol=1e-10
        signs=np.sign(dif[np.isfinite(dif)&(np.abs(dif)>tol)])
        turns=np.sum(signs[1:]!=signs[:-1])
        peaks=np.sum((signs[:-1]>0)&(signs[1:]<0))
        result.update({label+'_finite_fraction':float(finite.mean()),label+'_positive_fraction':float((finite&(p>0)).mean()),
          label+'_turning_points':int(turns),label+'_peaks':int(peaks),label+'_max_rate':float(np.nanmax(p)),
          label+'_grid_peak_C':float(x[np.nanargmax(p)]),label+'_nondecreasing_fraction':float(np.mean(dif>=-tol))})
        for t,v in zip(x[::10],p[::10]):gridrows.append(dict(Stage=r.Stage,Diet=r.Diet,domain=label,Temp=t,rate=v))
    out.append(result)
pd.DataFrame(out).to_csv(ROOT/'results/original_equations_audit.csv',index=False)
pd.DataFrame(gridrows).to_csv(ROOT/'results/original_equations_grid.csv',index=False)
pd.DataFrame(points).to_csv(ROOT/'results/original_equations_residuals.csv',index=False)
print(pd.DataFrame(out)[['Stage','Diet','numeric_constant_occurrences','recomputed_R2','RMSE_absolute_difference','training_range_peaks','stress_test_only_finite_fraction']].to_string(index=False))
