"""Run symbolic regression through the Python PySR interface and Julia search backend.

Expression structure, constants and final candidate selection use training data
within every held-temperature fold. Each prespecified complexity penalty is
reported separately. Full-data seed variation measures algorithmic sensitivity,
not biological sampling uncertainty.
"""
from pathlib import Path
import os, json, time, sys, traceback, argparse, hashlib, sysconfig
ROOT=Path(__file__).resolve().parents[1]
# Julia discovery is controlled by the user environment; no local workspace paths are assumed.
python_library=Path(sys.base_prefix)/'lib'/str(sysconfig.get_config_var('LDLIBRARY'))
if python_library.exists():os.environ.setdefault('JULIA_PYTHONCALL_LIB',str(python_library))
os.environ.setdefault('PYTHON_JULIACALL_THREADS','1')
os.environ.setdefault('JULIA_NUM_GC_THREADS','1')
import numpy as np
import pandas as pd
from input_checks import read_summary_data

SEED=20261023
RATE_SCALE=.05
BASE=dict(niterations=400,populations=4,population_size=60,
    ncycles_per_iteration=20,maxsize=15,maxdepth=8,
    binary_operators=['+','-','*'],unary_operators=['sqrt','exp'],
    elementwise_loss='loss(prediction, target) = (exp(prediction) - target)^2',
    model_selection='accuracy',loss_scale='linear',
    complexity_of_operators={'+':1,'-':1,'*':1,'sqrt':1,'exp':1},
    complexity_of_constants=1,complexity_of_variables=1,
    use_frequency=False,use_frequency_in_tournament=False,
    crossover_probability=.2,
    weight_add_node=2.47,weight_insert_node=.0112,weight_delete_node=.870,
    weight_do_nothing=.273,weight_mutate_constant=.0346,
    weight_mutate_operator=.293,weight_mutate_feature=.1,weight_swap_operands=.198,
    weight_rotate_tree=4.26,weight_randomize=.000502,weight_simplify=.00209,
    weight_optimize=0.,weight_backsolve=0.,
    optimizer_algorithm='BFGS',optimizer_nrestarts=2,optimizer_iterations=8,
    optimize_probability=.14,parallelism='serial',deterministic=True,
    precision=64,progress=False,verbosity=0,early_stop_condition=None,
    timeout_in_seconds=None,max_evals=None,
    nested_constraints={'exp':{'exp':0}},
    update=False)

def run_fit(t,y,tag,search_lambda=.01,seed=SEED):
    """Search training data, screen the declared temperature grid and select a candidate.
    
    Selection minimizes scaled training MSE plus lambda times latent-tree complexity.
    The held-out response is not provided to this function."""
    from pysr import PySRRegressor
    cfg=dict(BASE,parsimony=search_lambda,random_state=seed,
       output_directory=str(ROOT/'results/pysr_searches'),run_id=tag)
    model=PySRRegressor(**cfg)
    start=time.monotonic()
    model.fit(np.asarray(t).reshape(-1,1),np.asarray(y)/RATE_SCALE)
    front=model.equations_.copy()
    front.drop(columns=[c for c in ['lambda_format','sympy_format'] if c in front],inplace=True)
    front.to_csv(ROOT/f'results/pysr_searches/{tag}_front.csv',index=False)
    with open(ROOT/f'results/pysr_searches/{tag}_parameters.json','w') as f:
        json.dump(model.get_params(),f,indent=2,default=str)
    viable=[]
    for idx,r in model.equations_.iterrows():
        with np.errstate(all='ignore'):
            phat=RATE_SCALE*np.exp(model.predict(np.asarray(t).reshape(-1,1),index=idx))
            grid=np.linspace(15,35,401)
            gp=RATE_SCALE*np.exp(model.predict(grid.reshape(-1,1),index=idx))
        if not (np.isfinite(phat).all() and np.isfinite(gp).all() and (gp>0).all()):continue
        mse=float(np.mean(((phat-y)/RATE_SCALE)**2))
        viable.append((mse+search_lambda*float(r.complexity),float(r.complexity),idx,mse))
    if not viable:raise RuntimeError('No candidate finite and positive throughout prespecified screening grid')
    score,c,idx,mse=min(viable)
    return model,idx,dict(equation=str(model.equations_.loc[idx,'equation']),
       complexity=c,train_RMSE=RATE_SCALE*np.sqrt(mse),penalized_training_score=score,
       search_lambda=search_lambda,selection_lambda=search_lambda,seed=seed,
       seconds=time.monotonic()-start)

def main():
    """Run the prespecified fold, penalty and seed schedule; retain completed searches."""
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--smoke-test',action='store_true',help='Test software on a synthetic five-point function, not empirical data')
    parser.add_argument('--group',action='append',help='Optional exact group such as Adult|100%%')
    parser.add_argument('--limit-runs',type=int,help='Bound the number of new fits in this invocation; results remain partial')
    args=parser.parse_args()
    if args.smoke_test:
        BASE.update(niterations=8,populations=2,population_size=20,ncycles_per_iteration=2,maxsize=9)
        t=np.array([15.,20.,25.,30.,35.]);y=.05*np.exp(-((t-27)/12)**2)
        model,idx,details=run_fit(t,y,'software_smoke')
        reconstructed=.05*np.exp(model.predict(t.reshape(-1,1),index=idx))
        assert np.isfinite(reconstructed).all() and (reconstructed>0).all()
        assert np.isclose(np.sqrt(np.mean((reconstructed-y)**2)),details['train_RMSE'])
        details.update(status='PASS',scope='Synthetic software smoke test; not validation of biological models')
        (ROOT/'results/pysr_software_smoke.json').write_text(json.dumps(details,indent=2))
        print(json.dumps(details,indent=2));return
    data=read_summary_data(ROOT/'data/supplied_summary_values.csv');rows=[];curves=[]
    import pysr
    from pysr.julia_import import jl
    configuration=dict(BASE,rate_scale=RATE_SCALE,nominal_lambda=.01,
       held_temperature_lambda_sensitivity=[.001,.01,.1],full_fit_seeds=[SEED,SEED+1,SEED+2],
       selection='minimize training MSE on rate/0.05 scale + lambda * unit tree node count',
       screening='finite positive predictions on fixed 401-point 15-35 C grid; not a formal interval guarantee',
       versions={'pysr':pysr.__version__,'julia':str(jl.VERSION),'python':sys.version},
       input_sha256=hashlib.sha256((ROOT/'data/supplied_summary_values.csv').read_bytes()).hexdigest(),
       caveat='PySR configuration for the reported held-temperature and full-data analyses')
    configpath=ROOT/'results/pysr_configuration.json'
    if (ROOT/'results/pysr_runs.csv').exists():
        if not configpath.exists() or json.loads(configpath.read_text())!=configuration:
            raise RuntimeError('Existing run configuration differs; archive previous outputs before changing experiment')
        rows=pd.read_csv(ROOT/'results/pysr_runs.csv').to_dict('records')
        if (ROOT/'results/pysr_full_curves.csv').exists():curves=pd.read_csv(ROOT/'results/pysr_full_curves.csv').to_dict('records')
    configpath.write_text(json.dumps(configuration,indent=2))
    completed={(r['Stage'],r['Diet'],r['fold']) for r in rows}
    new_runs=0
    for (stage,diet),g in data.groupby(['Stage','Diet'],sort=True):
        g=g.sort_values('Temp');t=g.Temp.to_numpy();y=g.rate.to_numpy()
        if args.group and f'{stage}|{diet}' not in args.group:continue
        if len(t)<5:
            print('Skipping five-temperature comparison: insufficient observed temperatures',stage,diet,len(t),flush=True)
            continue
        # Each lambda is declared before validation and reported separately; never tune from held-out errors.
        tasks=[]
        for lam in [.01,.001,.1]:
            suffix='' if lam==.01 else f'_lambda_{lam:g}'
            tasks.append(('full'+suffix,np.ones(len(t),dtype=bool),lam,SEED))
            tasks += [(f'hold_{t[i]:g}'+suffix,np.arange(len(t))!=i,lam,SEED) for i in range(len(t))]
        tasks += [('full_seed_2',np.ones(len(t),dtype=bool),.01,SEED+1),
                  ('full_seed_3',np.ones(len(t),dtype=bool),.01,SEED+2)]
        for fold,keep,lam,seed in tasks:
            if (stage,diet,fold) in completed:continue
            if args.limit_runs is not None and new_runs>=args.limit_runs:return
            tag=f'{stage}_{diet.replace("%", "pct")}_{fold}'
            row=dict(Stage=stage,Diet=diet,fold=fold,n_train=int(keep.sum()),
               search_lambda=lam,seed=seed,status='FAILED',provenance='Digitized development summaries')
            print('Starting PySR',tag,flush=True)
            try:
                model,idx,details=run_fit(t[keep],y[keep],tag,lam,seed)
                row.update(details,status='complete')
                if not keep.all():
                    with np.errstate(all='ignore'):
                        pred=float((RATE_SCALE*np.exp(model.predict(t[~keep].reshape(-1,1),index=idx)))[0])
                    row.update(held_Temp=float(t[~keep][0]),observed=float(y[~keep][0]),predicted=pred,
                         error=pred-float(y[~keep][0]),split_type='endpoint_extrapolation' if t[~keep][0] in [t.min(),t.max()] else 'interior_interpolation')
                    if not np.isfinite(pred):row['status']='FAILED nonfinite test prediction'
                else:
                    x=np.linspace(0,50,1001)
                    with np.errstate(all='ignore'):p=RATE_SCALE*np.exp(model.predict(x.reshape(-1,1),index=idx))
                    for tt,pp in zip(x,p):curves.append(dict(Stage=stage,Diet=diet,fold=fold,Temp=tt,rate=pp))
            except Exception as e:
                row['failure']=repr(e);traceback.print_exc()
            rows.append(row)
            new_runs+=1
            pd.DataFrame(rows).to_csv(ROOT/'results/pysr_runs.csv',index=False)
            pd.DataFrame(curves).to_csv(ROOT/'results/pysr_full_curves.csv',index=False)
            print('Finished PySR',tag,row['status'],flush=True)
    pd.DataFrame(rows).to_csv(ROOT/'results/pysr_runs.csv',index=False)
    print('Recorded fits:',len(rows),'; new fits this invocation:',new_runs,flush=True)

if __name__=='__main__':main()
