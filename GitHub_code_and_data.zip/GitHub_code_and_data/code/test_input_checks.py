"""Tests for input errors that would invalidate or leak a sparse-data analysis."""
import tempfile
from pathlib import Path
import pandas as pd
from input_checks import read_summary_data,intake_report
with tempfile.TemporaryDirectory() as tmp:
    p=Path(tmp)/'data.csv'
    d=pd.DataFrame(dict(Stage=['Adult']*2,Diet=['12%']*2,Temp=[25,30],Days=[20,14]))
    d.to_csv(p,index=False)
    report=intake_report(read_summary_data(p))
    assert not report['groups'][0]['eligible_for_predeclared_five_temperature_comparison']
    assert not report['scientific_verification_pass']
    for bad in [pd.concat([d,d.iloc[[0]]],ignore_index=True),d.assign(Days=[0,14]),d.assign(point_type='fitted_curve'),d.assign(rate=[999,999]),d.assign(Temp=[22,30])]:
        bad.to_csv(p,index=False)
        try:read_summary_data(p)
        except ValueError:pass
        else:raise AssertionError('Invalid inputs were accepted')
print('PASS: missing-group eligibility, duplicate summaries, zero durations, fitted-curve inputs, rate consistency and declared temperature design')
