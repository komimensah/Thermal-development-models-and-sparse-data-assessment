"""Crop PRISM monthly normals without resampling; export cell-centre coordinates.
Usage: python code/prepare_spatial_climate.py --source-dir /path/to/extracted/month/folders
"""
from pathlib import Path
import argparse,json,hashlib,calendar,shutil
import numpy as np
import pandas as pd
import rasterio
from rasterio.mask import mask
from rasterio.warp import transform_geom,transform as transform_xy
from shapely.geometry import shape
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'spatial'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source-dir',type=Path,required=True);args=ap.parse_args()
 meta=[];stats=[]
 for region in ['Nebraska','Lancaster_County_Nebraska']:
  g=json.loads((OUT/f'{region}.geojson').read_text())['features'][0]['geometry']
  arrs=[];rows=[];profile=None
  for mon in range(1,13):
   files=list((args.source_dir/f'{mon:02d}').glob('*.tif'));assert len(files)==1
   with rasterio.open(files[0]) as src:
    geom=transform_geom('EPSG:4326',src.crs,g)
    a,tr=mask(src,[geom],crop=True,filled=False,all_touched=False)
    a=a[0].filled(np.nan).astype('float32')
    assert np.isfinite(a).any(),region
    if profile is None:
     profile=src.profile.copy();profile.update(driver='GTiff',count=12,dtype='float32',height=a.shape[0],width=a.shape[1],transform=tr,nodata=float('nan'),compress='deflate')
     profile.pop('blockxsize',None);profile.pop('blockysize',None);profile.pop('tiled',None)
     r,c=np.where(np.isfinite(a));x,y=rasterio.transform.xy(tr,r,c)
     lon,lat=transform_xy(src.crs,'EPSG:4326',x,y)
     point=pd.DataFrame({'row':r,'column':c,'longitude_WGS84':lon,'latitude_WGS84':lat})
    else:assert a.shape==arrs[0].shape and tr==profile['transform']
    point[f'tmean_{mon:02d}_C']=a[r,c]
    arrs.append(a)
    valid=a[np.isfinite(a)]
    stats.append(dict(region=region,month=mon,n_valid_cells=len(valid),min_C=float(valid.min()),mean_cell_C=float(valid.mean()),max_C=float(valid.max()),within_15_35_cells=int(((valid>=15)&(valid<=35)).sum()),below_15_cells=int((valid<15).sum()),above_35_cells=int((valid>35).sum())))
    if region=='Nebraska':
     dest=OUT/'source_metadata'/f'{mon:02d}';dest.mkdir(parents=True,exist_ok=True)
     for p in files[0].parent.iterdir():
      if p.suffix!='.tif':shutil.copy2(p,dest/p.name)
     meta.append(dict(month=mon,source_filename=files[0].name,source_sha256=hashlib.file_digest(open(files[0],'rb'),'sha256').hexdigest(),source_crs=str(src.crs),source_resolution=list(src.res),source_units='degrees Celsius (PRISM metadata)',source_scale=list(src.scales),source_offset=list(src.offsets)))
  with rasterio.open(OUT/f'{region}_PRISM_tmean_1991_2020_monthly_4km.tif','w',**profile) as dst:
   for mon,a in enumerate(arrs,1):
    dst.write(a,mon);dst.set_band_description(mon,f'{calendar.month_name[mon]} 1991–2020 normal tmean °C');dst.set_band_unit(mon,'degC')
   dst.update_tags(provider='PRISM Group, Oregon State University',source_url='https://prism.oregonstate.edu/normals/',access_date='2026-10-25',normal_period='1991-2020',dataset_version='M5',native_grid='2.5 arc-minutes, approximately 4 km',crop='Census boundary; cell centre inside polygon; no resampling',interpretation='Climate projection scenario, not laboratory or independent biological observations')
  point.to_csv(OUT/f'{region}_temperature_grid_cell_centres.csv',index=False)
  if region.startswith('Lancaster'):
   fig,axs=plt.subplots(3,4,figsize=(10,10),sharex=True,sharey=True)
   for mon,(ax,a) in enumerate(zip(axs.flat,arrs),1):
    b=rasterio.transform.array_bounds(a.shape[0],a.shape[1],profile['transform'])
    im=ax.imshow(a,extent=[b[0],b[2],b[1],b[3]],vmin=-5,vmax=30,cmap='coolwarm',origin='upper',interpolation='nearest')
    geo=shape(g)
    for poly in ([geo] if geo.geom_type=='Polygon' else geo.geoms):
     xx,yy=poly.exterior.xy;ax.plot(xx,yy,'k-',lw=.6)
    ax.set_title(calendar.month_abbr[mon]);ax.tick_params(labelsize=7)
   cax=fig.add_axes([.88,.20,.025,.55]);fig.colorbar(im,cax=cax,label='Monthly normal mean air temperature (°C)')
   fig.suptitle('Lancaster County, Nebraska\nPRISM monthly normals 1991–2020, native ~4 km grid')
   fig.text(.05,.02,'PRISM Group, Oregon State University • https://prism.oregonstate.edu • accessed 25 October 2026\nCounty boundary: U.S. Census Bureau TIGERweb. Climate scenario; not experimental temperatures.',fontsize=8)
   fig.subplots_adjust(bottom=.09,top=.90,right=.84,hspace=.2)
   fig.savefig(OUT/'Lancaster_monthly_temperature_preview.png',dpi=180);plt.close(fig)
 pd.DataFrame(stats).to_csv(OUT/'temperature_coverage_by_month.csv',index=False)
 (OUT/'climate_preparation_metadata.json').write_text(json.dumps({'provider':'PRISM Group, Oregon State University','source_url':'https://prism.oregonstate.edu/normals/','access_date':'2026-10-25','normal_period':'1991–2020','resolution':'native approximately 4 km; no resampling','county':'Lancaster County, Nebraska, FIPS 31109','geographic_justification':'Firth is the colony origin collection locality; not the exact experimental site','coordinate_exports':'Grid-cell centres from an existing modeled climate raster, not weather station observations','months':meta},indent=2))
 print(pd.DataFrame(stats).query("region=='Lancaster_County_Nebraska'").to_string(index=False))
if __name__=='__main__':main()
