# Optional R launcher for the Python canonical-model and verification scripts.
# Usage: Rscript code/main.R /absolute/path/to/python
# Symbolic search is launched separately with code/rerun_pysr.py.
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Supply the Python executable as the only argument")
script_arg <- grep("^--file=", commandArgs(), value = TRUE)
script_dir <- dirname(normalizePath(sub("^--file=", "", script_arg)))
for (script in c("audit_inputs.py", "reanalyse.py", "make_figures.py", "verify_results.py")) {
  status <- system2(args[1], shQuote(file.path(script_dir, script)))
  if (status != 0L) stop(paste("Analysis failed in", script))
}
message("Canonical fits and computational verification completed. Results are in results/.")
