# Publication release changes

The release cleans script comments, module and function documentation, figure labels and descriptive metadata. It removes workspace-specific Julia discovery and portable parameter records replace the local output directory with `results/pysr_searches`. The numerical fitting functions, parameter bounds, seeds, search configuration, expression strings and observed values are retained.

The input CSV's provenance label now describes WebPlotDigitizer acquisition rather than carrying the earlier editorial-status label. CSV newline normalization also changes its byte hash. Numerical columns are unchanged. The matching hash in `results/pysr_configuration.json` refers to the release input.

Original input SHA256: `35fad25dd5048f6334dd4e5a3403a2461da9c826e5b74f0bf3b390c063041e28`
Release input SHA256: `0f81689e0f8e1f9e3ad073fc9ab065ab597155b77cd8a56242cfa666e36f7dc4`

Raw statistical outcomes are not recast as validated biological observations. The source-outcome limitation, sampling limitations, finite-grid caveats and distinction between climate-model agreement and biological validation remain documented.

Private reviewer records, document-location records, working-status notes, third-party article PDFs, Python caches, backup files and machine-specific pickle checkpoints are omitted. Symbolic candidate fronts, hall-of-fame CSVs and parameter JSONs remain. The original working analysis directory is unchanged.

Verification results are recorded in `release_verification.json` after checks complete. The comment cleanup does not constitute a new 160-search symbolic-regression run.
