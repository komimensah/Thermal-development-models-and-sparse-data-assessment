# Software roles and manuscript wording

Suggested Methods sentence:

“Symbolic regression was implemented in Python using PySR 2.7.2, which used the SymbolicRegression.jl backend running under Julia 1.10.10 [6].”

Suggested supplementary sentence:

“Canonical model fitting, held-temperature assessment, numerical-domain diagnostics, digitization-sensitivity calculations and spatial model-agreement analyses were performed in Python. Optional R scripts provide command-line entry points to the Python analysis.”

The current release does not provide an independent R analysis or a standalone Julia analysis. `code/rerun_pysr.py` controls symbolic search and passes its custom Julia loss expression to the backend. `environment/Project.toml` and `Manifest.toml` record the Julia environment. Python package versions are recorded in `environment/python_dependencies.json` and the requirements files.

| Task | Main script | Language |
| --- | --- | --- |
| Input checks and reference-expression audit | input_checks.py; audit_inputs.py | Python |
| Canonical fits and held-temperature folds | reanalyse.py | Python |
| Symbolic structure and constant search | rerun_pysr.py | Python interface; Julia backend |
| Saved-expression verification and summaries | summarize_pysr.py; verify_results.py | Python |
| Digitization sensitivity | digitization_sensitivity.py | Python |
| Climate cropping and model projection | prepare_spatial_climate.py; project_spatial_models.py | Python |
| Optional command launchers | main.R; Spatial_analysis.R | R, calling Python |
